conda env create -f enviroment.yaml &&
conda activate rcnn1.0 &&
pip install -r requirement.txt
