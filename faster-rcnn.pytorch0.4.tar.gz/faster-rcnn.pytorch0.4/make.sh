conda env create -f enviroment.yaml &&
conda activate rcnn0.4 &&
pip install -r requirement.txt
